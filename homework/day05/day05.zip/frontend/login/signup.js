// 휴대폰 인증 토큰 전송하기
const GetValidationNumber = () => {
  console.log('인증 번호 전송')
}

// 회원 가입 API 요청
const submitSignup = () => {
  console.log('회원 가입 완료')
}
